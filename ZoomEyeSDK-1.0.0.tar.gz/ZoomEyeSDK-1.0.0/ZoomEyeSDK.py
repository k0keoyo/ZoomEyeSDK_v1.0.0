#!/usr/bin/python
#coding:utf-8

import urllib2
import urllib
import json

def ZoomEye_Login(g_strUsername,g_strPasswd):
    m_strZoomEyeLoginUrl = 'http://api.zoomeye.org/user/login'
    m_strfPostData = {"username":g_strUsername,"password":g_strPasswd}
    m_strjData = json.dumps(m_strfPostData)#post json 格式
    req = urllib2.Request(url = m_strZoomEyeLoginUrl,data = m_strjData)
    #req.add_header('User-agent','Mozilla 5.10')
    m_strResultData = urllib2.urlopen(req).read()
    #print m_strResultData
    return m_strResultData

def ZoomEye_BaseInfo(g_strLoginToken):
    m_strZoomEyeSearchUrl = 'http://api.zoomeye.org/resources-info'
    req = urllib2.Request(url = m_strZoomEyeSearchUrl)
    req.add_header("Authorization",g_strLoginToken)
    m_strResultData = urllib2.urlopen(req).read()
    #print m_strResultData
    return m_strResultData

def ZoomEye_HostData(g_strReqHostInfo,m_strReqPage,g_strLoginToken):
    m_strZoomEyeSearchUrl = 'http://api.zoomeye.org/host/search?query='+g_strReqHostInfo+'&page='+str(m_strReqPage)#+'&facet=app,os'
    req = urllib2.Request(url = m_strZoomEyeSearchUrl)
    req.add_header("Authorization",g_strLoginToken)
    m_strResultData = urllib2.urlopen(req).read()
    #print m_strResultData
    return m_strResultData

def ZoomEye_WebData(g_strReqWebInfo,m_strReqPage,g_strLoginToken):
    m_strZoomEyeSearchUrl = 'http://api.zoomeye.org/web/search?query='+g_strReqWebInfo+'&page='+str(m_strReqPage)#+
    req = urllib2.Request(url = m_strZoomEyeSearchUrl)
    req.add_header("Authorization",g_strLoginToken)
    m_strResultData = urllib2.urlopen(req).read()
    return m_strResultData