#!/usr/bin/python
#coding:utf-8

from distutils.core import setup

setup(
    name = 'ZoomEyeSDK',
    version = '1.0.0',
    py_modules = ['ZoomEyeSDK'],
    author = 'k0shl',
    author_email = 'k0pwn_0110@sina.cn',
    description = 'Module demo'
)